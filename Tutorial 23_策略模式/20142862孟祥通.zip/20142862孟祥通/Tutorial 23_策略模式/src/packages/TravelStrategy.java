package packages;

public interface TravelStrategy {

	public void travel();
}
