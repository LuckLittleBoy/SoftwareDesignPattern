package packages;

public interface Road {

	void bedrive(String cheType,String name);
}
