package packages;

public class Mainframe {

	private Memory memory;
	private CPU cpu;
	private HardDisk hd;
	private OS os;
	public Mainframe()
	{
		memory = new Memory();
		cpu = new CPU();
		hd = new HardDisk();
		os = new OS();
	}
	
	public void on()
	{
		memory.check();
		cpu.run();
		hd.read();
		os.load();
	}
}
