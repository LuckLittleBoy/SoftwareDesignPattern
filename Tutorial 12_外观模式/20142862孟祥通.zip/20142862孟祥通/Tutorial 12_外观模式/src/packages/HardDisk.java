package packages;

public class HardDisk {

	public void read()
	{
		System.out.println("Ӳ�̶�ȡ");
	}
}
