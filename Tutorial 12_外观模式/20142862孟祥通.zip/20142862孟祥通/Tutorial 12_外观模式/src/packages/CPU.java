package packages;

public class CPU {

	public void run()
	{
		System.out.println("CPU����");
	}
}
