package packages;

public class Client {

	public static void main(String args[])
	{
		Mainframe mf = new Mainframe();
		mf.on();
	}
}
