package packages;

public class Memory {

	public void check()
	{
		System.out.println("�ڴ��Լ�");
	}
}
