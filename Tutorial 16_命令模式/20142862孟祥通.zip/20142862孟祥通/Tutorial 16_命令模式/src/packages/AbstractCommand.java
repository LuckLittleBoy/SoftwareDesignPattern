package packages;

public abstract class AbstractCommand {

	public abstract int execute(int value);
	public abstract int redo();
	public abstract int undo();
}
