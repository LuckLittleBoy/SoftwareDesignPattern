package packages;

import java.util.ArrayList;

public class ConcreteCommand extends AbstractCommand {
	private Adder adder = new Adder();
	private ArrayList<Integer> list =  new ArrayList<Integer>();
	private int index = -1;

	public int execute(int value)
	{
		for(int i = index+1; i<list.size();i++)
		{
			list.remove(i);
		}
		list.add(value);
		index++;
		return adder.add(value);
	}
	public int redo()
	{
		int result = adder.add(list.get(index));
		index++;
		return result;
	}
	public int undo()
	{
		int result = adder.add(-list.get(index));
		index--;
		return result;
	}
}
