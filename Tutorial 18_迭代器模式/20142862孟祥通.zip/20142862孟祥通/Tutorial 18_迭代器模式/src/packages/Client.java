package packages;

import java.util.*;

public class Client {

	public static void process(List<Student> s)
	{
		Iterator<Student> i= (Iterator<Student>)s.iterator();
	
		while(i.hasNext())
		{
			Student stu = i.next();
			System.out.println(stu.sno + stu.name + stu.age);
		}
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void sortIntMethod(List<Student> list)
	{
		Collections.sort(list,new Comparator(){
			public int compare(Object o1,Object o2)
			{
				Student stu1 = (Student) o1;
				Student stu2 = (Student) o2;
				if(stu1.getSno() > stu2.getSno())
				{
					return 1;
				}
				else
				{
					return -1;
				}
			}
		});
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void reverseIntMethod(List<Student> list)
	{
		Collections.sort(list,new Comparator(){
			public int compare(Object o1,Object o2)
			{
				Student stu1 = (Student) o1;
				Student stu2 = (Student) o2;
				if(stu1.getSno() < stu2.getSno())
				{
					return 1;
				}
				else
				{
					return -1;
				}
			}
		});
	}
	
	public static void main(String args[])
	{
		List<Student> list = new ArrayList<Student>();
		Student s1 = new Student();
		Student s2 = new Student();
		Student s3 = new Student();
		s1.setStudent(3, "����ͨ", 21);
		s2.setStudent(1, "����", 21);
		s3.setStudent(2, "����", 21);
		
		list.add(s1);
		list.add(s2);
		list.add(s3);
		
		sortIntMethod(list);
		process(list);
		
		reverseIntMethod(list);
		process(list);
	}
}
