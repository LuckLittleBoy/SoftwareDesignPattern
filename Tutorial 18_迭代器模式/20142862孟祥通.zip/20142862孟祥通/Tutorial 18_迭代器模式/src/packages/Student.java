package packages;

public class Student {
	
	int sno;
	String name;
	int age;
	
	public void setStudent(int sno,String name,int age)
	{
		this.sno = sno;
		this.name = name;
		this.age = age;
	}
	
	public int getSno()
	{
		return sno;
	}
	public String getName()
	{
		return name;
	}
	public int getAge()
	{
		return age;
	}
}
