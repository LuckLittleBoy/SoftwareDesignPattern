package packages;
public interface Product
{
	void accept(Visitor visitor);
}