package tutorial8;

public interface Cat {
	public void mouse();
}
