package tutorial8;

public interface Dog {
	public void wang();
}
