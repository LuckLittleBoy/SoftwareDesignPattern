package packages;

public class Client {

	public static void main(String args[])
	{
		Leader objZhuren,objManager,objFuManager,objZongManager;
		
		objZhuren = new Zhuren("����");
		objManager = new Manager("��ǿ");
		objFuManager = new FuManager("����");
		objZongManager = new ZongManager("�");
		
		objZhuren.setSuccessor(objManager);
		objManager.setSuccessor(objFuManager);
		objFuManager.setSuccessor(objZongManager);
		
		Goods gd1 = new Goods(0.7);
		objZhuren.handleRequest(gd1);
		
		Goods gd2 = new Goods(4.5);
		objZhuren.handleRequest(gd2);
		
		Goods gd3 = new Goods(8.8);
		objZhuren.handleRequest(gd3);
		
		Goods gd4 = new Goods(17.5);
		objZhuren.handleRequest(gd4);
		
		Goods gd5 = new Goods(22.2);
		objZhuren.handleRequest(gd5);
	}
}
