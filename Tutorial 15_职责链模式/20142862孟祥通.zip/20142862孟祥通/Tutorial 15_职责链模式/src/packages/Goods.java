package packages;

public class Goods {

	private double money;
	
	public Goods(double money)
	{
		this.money = money;
	}
	
	public void setMoney(double money)
	{
		this.money = money;
	}
	
	public double getMoney()
	{
		return (this.money);
	}
}
