package factory;

public class BWoman implements Woman{
	public void WomanDisplay(){
		System.out.println("��ɫŮ��");
	}
}
