package factory;

public class YWoman implements Woman{
	public void WomanDisplay(){
		System.out.println("��ɫŮ��");
	}
}
