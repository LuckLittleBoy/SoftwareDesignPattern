package factory;

public class WWoman implements Woman{
	public void WomanDisplay(){
		System.out.println("��ɫŮ��");
	}
}
