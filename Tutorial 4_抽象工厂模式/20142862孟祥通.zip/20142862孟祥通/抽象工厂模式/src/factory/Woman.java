package factory;

public interface Woman {
	public  void WomanDisplay();
}
