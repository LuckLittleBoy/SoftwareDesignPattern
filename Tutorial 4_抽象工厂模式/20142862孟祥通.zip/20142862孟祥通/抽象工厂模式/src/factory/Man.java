package factory;

public interface Man {
	public void manDisplay();
}
