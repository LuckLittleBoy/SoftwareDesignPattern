package packages;

public class Color {

	private String color;
	
	public Color(String color)
	{
		this.color = color;
	}
	
	public void setColor(String color)
	{
		this.color = color;
	}
	
	public String getColor()
	{
		return this.color;
	}
}
