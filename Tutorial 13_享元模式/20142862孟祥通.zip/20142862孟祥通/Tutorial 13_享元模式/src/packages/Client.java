package packages;

public class Client {

	public static void main(String args[])
	{
		TextDoc td1,td2,td3,td4;
		TextDocFactory tdf = new TextDocFactory();
		
		td1 = tdf.getTextDoc("HelloWorld");
		td1.use(new Color("��ɫ"));
		
		td2 = tdf.getTextDoc("HelloWorld");
		td2.use(new Color("��ɫ"));
		
		td3 = tdf.getTextDoc("OtherText");
		td3.use(new Color("��ɫ"));
		
		td4 = tdf.getTextDoc("OtherText");
		td4.use(new Color("��ɫ"));
	}
}
