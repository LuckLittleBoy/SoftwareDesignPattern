package packages;
import java.util.*;

public class TextDocFactory {

	private ArrayList textdoc = new ArrayList();
	
	public TextDocFactory()
	{
		TextDoc td1 = new HelloWorld("HelloWorld");
		textdoc.add(td1);
		TextDoc td2 = new OtherText("OtherText");
		textdoc.add(td2);
	}
	
	public TextDoc getTextDoc(String text)
	{
		if(text.equalsIgnoreCase("HelloWorld"))
		{
			return (TextDoc)textdoc.get(0);
		}
		else if(text.equalsIgnoreCase("OtherText"))
		{
			return (TextDoc)textdoc.get(1);
		}
		else
		{
			return null;
		}
	}
}
