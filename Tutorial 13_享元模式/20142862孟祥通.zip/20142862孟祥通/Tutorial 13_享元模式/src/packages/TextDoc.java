package packages;

public interface TextDoc {

	public String getText();
	public void use(Color color);
}
