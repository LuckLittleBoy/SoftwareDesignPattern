package packages;

public class GuPiao extends MySubject
{
	private int piao=0;
	public void jiang()
	{		
		for(Object obs:observers)
		{
			piao=-1;
			((MyObserver)obs).response(piao);
		}
		
	}

	@Override
	public void sheng() {
		// TODO �Զ����ɵķ������
		
		for(Object obs:observers)
		{
			piao=1;
			((MyObserver)obs).response(piao);
		}
	}	   	
}