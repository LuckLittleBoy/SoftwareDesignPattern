package packages;

public class Client
{
	public static void main(String a[])
	{
		MySubject subject=new GuPiao();
		
		MyObserver obs1;
		obs1=new GuMin();
		
		subject.attach(obs1);
		subject.jiang();
		
		MyObserver obs2;
		obs2=new GuMin();
		subject.attach(obs2);
		
		subject.sheng();		
	}
}