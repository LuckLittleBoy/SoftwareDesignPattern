package packages;

public final class SimplePhone implements Phone {

	public SimplePhone()
	{
		System.out.println("SimplePhone");
	}
	public void sound() {
		System.out.println("����������");
	}

}
