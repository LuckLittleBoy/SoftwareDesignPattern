package packages;

public interface Phone {
	public void sound();
}
