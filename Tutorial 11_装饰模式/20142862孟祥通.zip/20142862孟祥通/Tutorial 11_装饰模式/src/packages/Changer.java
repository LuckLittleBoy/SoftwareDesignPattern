package packages;

public class Changer implements Phone{

	private Phone phone;
	
	public Changer(Phone phone)
	{
		this.phone = phone;
	}
	@Override
	public void sound() {
		// TODO �Զ����ɵķ������
		phone.sound();
	}
}
