package packages;

public class Client {

	public static void main(String args[])
	{
		Phone phone;
		phone = new SimplePhone();
		phone.sound();
		
		System.out.println("-------------����-------------");
		
		JarPhone jp = new JarPhone(phone);
		jp.sound();
		
		System.out.println("-------------�ٴ�����-------------");
		
		ComplexPhone cp = new ComplexPhone(jp);
		cp.sound();
	}
}
