package packages;

public interface AbstractMatch {

	public void userInfo();
	public void matchPeople();
	public void setAge(int age);
}
