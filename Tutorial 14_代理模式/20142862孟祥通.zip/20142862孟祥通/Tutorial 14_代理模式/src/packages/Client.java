package packages;

public class Client {

	public static void main(String args[])
	{
		AbstractMatch match;
		match = (AbstractMatch)XMLUtil.getBean();
		
		match.setAge(20);
		match.userInfo();
		match.matchPeople();
		System.out.println("--------------------------------");
		match.setAge(17);
		match.userInfo();
		match.matchPeople();
	}
}
