package packages;

public class TaiComputerBuilder extends ComputerBuilder{

	public void buildCPU()
	{
		computer.setCPU("һ��̨ʽcpu");
	}
	public void buildARM()
	{
		computer.setARM("һ��̨ʽarm");
	}
	public void buildHD()
	{
		computer.setHD("һ��̨ʽhd");
	}
	public void buildMB()
	{
		computer.setMB("һ��̨ʽmb");
	}
}
