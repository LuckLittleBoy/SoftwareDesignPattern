package packages;

public class BenComputerBuilder extends ComputerBuilder{

	public void buildCPU()
	{
		computer.setCPU("һ���ʼǱ�cpu");
	}
	public void buildARM()
	{
		computer.setARM("һ���ʼǱ�arm");
	}
	public void buildHD()
	{
		computer.setHD("һ���ʼǱ�hd");
	}
	public void buildMB()
	{
		computer.setMB("һ���ʼǱ�mb");
	}
}
