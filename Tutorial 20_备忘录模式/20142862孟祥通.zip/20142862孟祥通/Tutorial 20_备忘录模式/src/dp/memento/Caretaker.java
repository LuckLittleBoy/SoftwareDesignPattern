package dp.memento;

import java.util.ArrayList;

public class Caretaker
{
	private ArrayList<Memento> mementoArr = new ArrayList<Memento>();
	int index = -1;
	public Memento getMemento()
	{
		if(index == -1)
		{
			System.out.println("����¼������Ϣ");
			return null;
		}
		index--;
		
		Memento memento = mementoArr.get(index);
		
		return memento;
	}
	public void setMemento(Memento memento)
	{
		for(int i = index + 1; i < mementoArr.size();i++)
		{
			mementoArr.remove(i);
		}
		
		mementoArr.add(memento);
		index++;
	}
}